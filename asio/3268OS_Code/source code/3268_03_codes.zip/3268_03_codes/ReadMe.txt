Each file is a standalone compilable example.
